module.exports = function(req, res){
	res.writeHead(404);
		res.end();
}